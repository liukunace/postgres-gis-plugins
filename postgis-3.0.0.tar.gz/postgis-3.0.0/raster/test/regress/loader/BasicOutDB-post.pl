unlink "loader/BasicOutDB.tif";
unlink "loader/BasicOutDB.opts";
